/****************************************************************************
** Meta object code from reading C++ file 'Level.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../battle_city_v6/Level.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Level.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSLevelENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSLevelENDCLASS = QtMocHelpers::stringData(
    "Level",
    "handleBulletCreation",
    "",
    "Bullet*",
    "bullet",
    "generateEnemy",
    "level",
    "increaseScore",
    "Enemy*",
    "enemy",
    "hitOnWall",
    "Wall*",
    "wall",
    "encounterWall",
    "togglePlayerOpacity",
    "setInvincibe"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSLevelENDCLASS_t {
    uint offsetsAndSizes[32];
    char stringdata0[6];
    char stringdata1[21];
    char stringdata2[1];
    char stringdata3[8];
    char stringdata4[7];
    char stringdata5[14];
    char stringdata6[6];
    char stringdata7[14];
    char stringdata8[7];
    char stringdata9[6];
    char stringdata10[10];
    char stringdata11[6];
    char stringdata12[5];
    char stringdata13[14];
    char stringdata14[20];
    char stringdata15[13];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSLevelENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSLevelENDCLASS_t qt_meta_stringdata_CLASSLevelENDCLASS = {
    {
        QT_MOC_LITERAL(0, 5),  // "Level"
        QT_MOC_LITERAL(6, 20),  // "handleBulletCreation"
        QT_MOC_LITERAL(27, 0),  // ""
        QT_MOC_LITERAL(28, 7),  // "Bullet*"
        QT_MOC_LITERAL(36, 6),  // "bullet"
        QT_MOC_LITERAL(43, 13),  // "generateEnemy"
        QT_MOC_LITERAL(57, 5),  // "level"
        QT_MOC_LITERAL(63, 13),  // "increaseScore"
        QT_MOC_LITERAL(77, 6),  // "Enemy*"
        QT_MOC_LITERAL(84, 5),  // "enemy"
        QT_MOC_LITERAL(90, 9),  // "hitOnWall"
        QT_MOC_LITERAL(100, 5),  // "Wall*"
        QT_MOC_LITERAL(106, 4),  // "wall"
        QT_MOC_LITERAL(111, 13),  // "encounterWall"
        QT_MOC_LITERAL(125, 19),  // "togglePlayerOpacity"
        QT_MOC_LITERAL(145, 12)   // "setInvincibe"
    },
    "Level",
    "handleBulletCreation",
    "",
    "Bullet*",
    "bullet",
    "generateEnemy",
    "level",
    "increaseScore",
    "Enemy*",
    "enemy",
    "hitOnWall",
    "Wall*",
    "wall",
    "encounterWall",
    "togglePlayerOpacity",
    "setInvincibe"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSLevelENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   56,    2, 0x06,    1 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       5,    1,   59,    2, 0x0a,    3 /* Public */,
       7,    2,   62,    2, 0x0a,    5 /* Public */,
      10,    2,   67,    2, 0x0a,    8 /* Public */,
      13,    1,   72,    2, 0x0a,   11 /* Public */,
      14,    0,   75,    2, 0x0a,   13 /* Public */,
      15,    0,   76,    2, 0x0a,   14 /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 8,    4,    9,
    QMetaType::Void, 0x80000000 | 11, 0x80000000 | 3,   12,    4,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject Level::staticMetaObject = { {
    QMetaObject::SuperData::link<QGraphicsScene::staticMetaObject>(),
    qt_meta_stringdata_CLASSLevelENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSLevelENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSLevelENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Level, std::true_type>,
        // method 'handleBulletCreation'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Bullet *, std::false_type>,
        // method 'generateEnemy'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'increaseScore'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Bullet *, std::false_type>,
        QtPrivate::TypeAndForceComplete<Enemy *, std::false_type>,
        // method 'hitOnWall'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wall *, std::false_type>,
        QtPrivate::TypeAndForceComplete<Bullet *, std::false_type>,
        // method 'encounterWall'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wall *, std::false_type>,
        // method 'togglePlayerOpacity'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setInvincibe'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void Level::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Level *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->handleBulletCreation((*reinterpret_cast< std::add_pointer_t<Bullet*>>(_a[1]))); break;
        case 1: _t->generateEnemy((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->increaseScore((*reinterpret_cast< std::add_pointer_t<Bullet*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<Enemy*>>(_a[2]))); break;
        case 3: _t->hitOnWall((*reinterpret_cast< std::add_pointer_t<Wall*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<Bullet*>>(_a[2]))); break;
        case 4: _t->encounterWall((*reinterpret_cast< std::add_pointer_t<Wall*>>(_a[1]))); break;
        case 5: _t->togglePlayerOpacity(); break;
        case 6: _t->setInvincibe(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Bullet* >(); break;
            }
            break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Bullet* >(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Enemy* >(); break;
            }
            break;
        case 3:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Bullet* >(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Wall* >(); break;
            }
            break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Wall* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Level::*)(Bullet * );
            if (_t _q_method = &Level::handleBulletCreation; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject *Level::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Level::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSLevelENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QGraphicsScene::qt_metacast(_clname);
}

int Level::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGraphicsScene::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    }
    return _id;
}

// SIGNAL 0
void Level::handleBulletCreation(Bullet * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
