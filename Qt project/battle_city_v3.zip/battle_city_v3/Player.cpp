#include "Player.h"
#include <QGraphicsRectItem>
#include <QKeyEvent>
#include <QGraphicsPixmapItem>

    Player::Player()
    {
        setPixmap(QPixmap(":/images/Players/Player1.png"));
    }
    void Player::keyPressEvent1(QKeyEvent *event)
    {
        // Player::keyPressEvent1(event); // Comment out this line to avoid recursion
        qDebug() << "Scene knows you pressed a key";
        QPointF pos = this->pos();  // Assuming 'player' is the current instance
        setTransformOriginPoint(boundingRect().center());

        if (event->key() == Qt::Key_Left && pos.x() > 0) {
            this->current_player_Direction = 1;
            setRotation(180); // 左邊
            setPos(pos + QPointF(-10, 0));
        } else if (event->key() == Qt::Key_Right && pos.x() < 700) {
            this->current_player_Direction = 2; // 改變方向為右邊
            setRotation(0); // 右邊
            setPos(pos + QPointF(10, 0));
        } else if (event->key() == Qt::Key_Up) {
            this->current_player_Direction = 3;
            setRotation(-90); // 上面
            setPos(pos + QPointF(0, -10));
        } else if (event->key() == Qt::Key_Down) {
            this->current_player_Direction = 4;
            setRotation(90); // 下面
            setPos(pos + QPointF(0, 10));
        }
    }



