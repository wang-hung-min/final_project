#include "widget.h"
#include "ui_widget.h"
#include "Scene.h"
#include <QGraphicsPixmapItem>

Widget::Widget(QWidget *parent)//宣告一個QWidget的物件叫parent
    : QWidget(parent)//直接初始化
    , ui(new Ui::Widget), scene(new Scene)//直接初始化
{

    ui->setupUi(this);
    scene->setSceneRect(0,0,780,780);//game's O(0,0)為左上角座標,800跟600為寬跟高
    ui->graphicsView->setScene(scene);//透過graphicsView看scene
    arrangeUI();

    // level = new Level(scene->getLevel(), scene->getPlayer());  // 先初始化
    connect(scene, &Scene::changeLevel, [=](){
        disconnect(scene, &Scene::changeLevel, nullptr, nullptr);
        Level *level = new Level(scene->getLevel(), scene->getPlayer());
        level->setSceneRect(0,0,1100,780);// 根據在 Scene 的選擇設定關卡
        connect(level, &Level::loseAndBackToStart, [=](){
            disconnect(level, &Level::loseAndBackToStart, nullptr, nullptr);
            scene = new Scene();
            ui->graphicsView->setScene(scene);
            arrangeUI();
        });
        arrangeUI();
        ui->graphicsView->setScene(level);
    });

    //讀檔
    connect(scene, &Scene::changeLevel_read, [=](){
        Level *level1 = new Level(scene->getLevel(), scene->getPlayer(),
                          scene->getHealth(), scene->getScore(),
                          scene->getMap(), scene->getTank(),scene->posX,scene->posY,scene->enemyInfoVector);
        connect(level1, &Level::loseAndBackToStart, [=](){
            disconnect(level1, &Level::loseAndBackToStart, nullptr, nullptr);
            scene = new Scene();
            ui->graphicsView->setScene(scene);
            arrangeUI();
        });
        arrangeUI();
        ui->graphicsView->setScene(level1);
    });

}

Widget::~Widget()
{
    scene->clear();
//    delete level;
//     delete ui;
    delete scene;
}

void Widget::on_startGameButton_clicked()
{
    scene->startGame();
    ui->graphicsView->setFocus();
}

void Widget::arrangeUI(){
    ui->graphicsView->setFixedSize(1000,780);//只能看到固定的大小
    ui->graphicsView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);//不給使用者show出上下調整的滾輪
    ui->graphicsView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->graphicsView->setBackgroundBrush(QBrush(QImage(":/images/Homepage/Solid_black.png")));
}
