#ifndef PLAYER_H
#define PLAYER_H

#include "Bullet.h"
#include "Enemy.h"
#include <QObject>
#include <QGraphicsPixmapItem>
#include <QTimer>
class Player :  public QGraphicsPixmapItem
{
public:
    Player(int who);
    int current_player_Direction=3;
    bool invincible = false;
    QPointF getCurPos() const;
    void setCurPos(QPointF newCurPos);
    int type;
private:
    QPointF curPos;
};

#endif // PLAYER_H
