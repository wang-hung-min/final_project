#include "Wall.h"
#include "Bullet.h"
#include "Player.h"
#include "Enemy.h"
#include "Player2.h"
#include <QGraphicsPixmapItem>
#include <QGraphicsScene>
#include <QList>
#include <QTimer>
#include <QDebug>

Wall::Wall(char type)
{
    state = true;
    switch(type)
    {
    case 'b':
        walltype = Walltype::BRICK;
        typeIndex = 0;
        setPixmap(QPixmap(":/images/Environment/Brick_Wall.png").scaled(15,15));
        break;
    case 's':
        walltype = Walltype::STEEL;
        typeIndex = 1;
        setPixmap(QPixmap(":/images/Environment/Steel_Wall.png").scaled(15,15));
        break;
    case 't':
        walltype = Walltype::TREE;
        typeIndex = 2;
        setPixmap(QPixmap(":/images/Environment/Trees.png").scaled(15,15));
        break;
    case 'w':
        walltype = Walltype::WATER;
        typeIndex = 3;
        setPixmap(QPixmap(":/images/Environment/Water.png").scaled(15,15));
        break;
    case 'i':
        walltype = Walltype::ICE;
        typeIndex = 4;
        setPixmap(QPixmap(":/images/Environment/Ice.png").scaled(15,15));
        break;
    }

    // 檢查牆有沒有被打到
    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &Wall::broken);
    timer->start(50);

    // 檢查坦克能不能繼續走
    blockTimer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &Wall::block);
    blockTimer->start(0);
}

void Wall::setState(bool ok)
{
    state = ok;
}

bool Wall::getState()
{
    return state;
}

int Wall::getTypeIndex()
{
    return typeIndex;
}

void Wall::broken() // 考慮 bullet v.s. wall
{
    QList<QGraphicsItem *> colliding_items = collidingItems();
    foreach (QGraphicsItem *item, colliding_items) {
        Bullet *bullet = dynamic_cast<Bullet*> (item);
        if (bullet) {
            if (walltype == Walltype::BRICK){
                emit breakWall(this, bullet);  // 這邊要讓子彈消失
            }
            else if (walltype == Walltype::STEEL){
                emit breakWall(this, bullet);  // 這邊要讓子彈消失
            }
//            else if (walltype == Walltype::TREE){
//            } else if (walltype == Walltype::WATER){
//            } else if (walltype == Walltype::ICE){
//            }
        }
    }
}

void Wall::block() // 考慮 tank v.s. wall
{
    QList<QGraphicsItem *> colliding_items = collidingItems();
    foreach (QGraphicsItem *item, colliding_items) {
        Player *player = dynamic_cast<Player*> (item);
        Player2 *player2 = dynamic_cast<Player2*> (item);
        Enemy *enemy = dynamic_cast<Enemy*> (item);
        if (player) {
            if (walltype == Walltype::BRICK || walltype == Walltype::STEEL || walltype == Walltype::WATER){
                qDebug() << "block player1"; // 有觸發
                // player->setPos1(player->pos()); // 沒用
                emit wallBlockTank(this, player);  // 這邊要讓坦克回到碰撞前
            }
        }
    }
}

//void Wall::block()
//{
//    Player *player = new Player();
//    QPointF playercenter = player->boundingRect().center();
//    QPointF wallcenter = this->boundingRect().center();
//    QLineF line(playercenter, wallcenter);
//    qreal distance = line.length();
//    qreal bound = player->boundingRect().width()/2 + this->boundingRect().width();

//    if (distance - 10 < bound){
//        player->
//    }
//}

