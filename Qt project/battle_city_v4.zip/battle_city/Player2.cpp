#include "player2.h"
#include <QKeyEvent>

Player2::Player2()
{
    setPixmap(QPixmap(":/images/Players/Player2.png").scaled(40,40));
}

void Player2::keyPressEvent2(QKeyEvent *event)
{
    qDebug() << "Scene knows you pressed a key2";
    QPointF pos2 = this->pos();
    setTransformOriginPoint(boundingRect().center());
    if (event->key() == Qt::Key_A && pos2.x() > 0) {
        current_player2_Direction = 1;
        setRotation(0); // 左邊
        setPos(pos2 + QPointF(-10, 0));
    } else if (event->key() == Qt::Key_D && pos2.x() < 700){
        current_player2_Direction = 2; // 改變方向為右邊
        setRotation(180); // 右邊
        setPos(pos2 + QPointF(10, 0));
    } else if (event->key() == Qt::Key_W) {

        current_player2_Direction = 3;
        setRotation(90); // 上面
        setPos(pos2 + QPointF(0, -10));
    } else if (event->key() == Qt::Key_S) {

        current_player2_Direction = 4;
        setRotation(-90); // 下面
        setPos(pos2 + QPointF(0, 10));
    }
}
