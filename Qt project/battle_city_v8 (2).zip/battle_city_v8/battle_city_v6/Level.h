#ifndef LEVEL_H
#define LEVEL_H

#include <vector>
#include <QTimer>
#include <QObject>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QSettings>
#include "Bullet.h"
#include "Health.h"
#include "Player.h"
#include "Player2.h"
#include "Score.h"
#include "Scene.h"
#include "Wall.h"
#include "Powerup.h"
#include "Enemy.h"
#include "Pausescreen.h"
#include "Explosion.h"
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QGraphicsTextItem>
#include <QFont>
using namespace std;

class Level : public QGraphicsScene
{
    Q_OBJECT
public:
    Level(int =0, int =0); //接收scene傳來的level跟number of players
    void setPlayer(int number);
    void generateMap(int level);
    void saveGame(); //目前不知怎麼搞
    void showGameover();//最後再寫
    void showSurvivor(int remains);     //生成畫面右邊的坦克剩餘圖

    void setTankRemainsVector(const vector<vector<char>>& tankRemains);
    const vector<vector<char>>& getTankRemainsVector() const;

    int current_player_Direction=3;
    int current_player2_Direction=3;
    void enemy_move();
    void checkPlayerWallCollision(Player *player, int playerDir);
    char tankType ;
    void checkPowerupCollision();
    void handlePowerupCollision();

    void togglePause()
    {
        isPaused = !isPaused;

        if (isPaused) {
            this->pauseScreen = new QGraphicsPixmapItem(QPixmap(":/images/Homepage/pause.png"));
            int x = (width() - this->pauseScreen->pixmap().width()) / 2;
            int y = (height() - this->pauseScreen->pixmap().height()) / 2;
            this->pauseScreen->setPos(x, y);

            this->pauseScreen->setOpacity(0.5);
            addItem(this->pauseScreen);
            setInitialEnemySpeed();
            pauseAllBullets();
            setOpacityForScene(0.5);  // 調整場景透明度
        } else {
            removeItem(this->pauseScreen);
            resumeAllBullets();
            resumeEnemyMovement();
            setOpacityForScene(1.0);  // 恢復場景透明度
        }
    }
    void pauseAllBullets()
    {
        QList<QGraphicsItem *> allItems = items();
        for (QGraphicsItem *item : allItems)
        {
            Bullet *bullet = dynamic_cast<Bullet*>(item);
            if (bullet)
            {
                bullet->setBulletSpeed(0);
            }
        }
    }
    void resumeAllBullets()
    {
        QList<QGraphicsItem *> allItems = items();
        for (QGraphicsItem *item : allItems)
        {
            Bullet *bullet = dynamic_cast<Bullet*>(item);
            if (bullet)
            {
                // 根據你的需求，這裡可能需要將速度設置為原來的值
                bullet->setBulletSpeed(bullet->getOriginalBulletSpeed());
            }
        }
    }
    void setOpacityForScene(qreal opacity)
    {
        QList<QGraphicsItem *> allItems = items();
        for (QGraphicsItem *item : allItems) {
            item->setOpacity(opacity);
        }
    }
    void resetShootStatus()
    {
        BulletFired = false;
        shootTimer->stop();
    }
    void handleStarEffect()
    {
        qDebug() << " handleStarEffect()";
        star++;
        if(star>=3){
            QList<QGraphicsItem *> allItems = items();
            for (QGraphicsItem *item : allItems) {
                Wall *wall = dynamic_cast<Wall*>(item);
                if (wall && wall->getState() && wall->getTypeIndex() == 1) {
                    removeItem(wall);
                    wall = new Wall('b');
                    wall->setPixmap(QPixmap(":/images/Environment/Steel_Wall.png").scaled(15,15));
                    addItem(wall);

                }
            }
        }
    }
    void handleTimerEffect()
    {
        qDebug() << " handleTimerEffect()";
        pauseTimer();
        setInitialEnemySpeed();  // Freeze enemy movement
        QTimer::singleShot(5000, this, &Level::resumeEnemyMovement);  // Resume enemy movement after 5 seconds
    }
    void resumeEnemyMovement()
    {
        isEnemyMovementFrozen = false;

        int i = 0;
        for (Enemy* enemy : enemyList)
        {
            enemy->setMoveSpeed(originalEnemySpeeds[i]);
            enemy->setBulletSpeed(originalEnemyShoot[i]);
            ++i;
        }
    }
    void pauseTimer()
    {
        isTimerPaused = true;
        spawnTimer->stop();
    }

    void resumeTimer()
    {
        isTimerPaused = false;
        spawnTimer->start();
    }
    void setInitialEnemySpeed()
    {
        isEnemyMovementFrozen = true;

        originalEnemySpeeds.clear();
        for (Enemy* enemy : enemyList)
        {

            originalEnemyShoot.append(enemy->getMoveSpeed());
            originalEnemySpeeds.append(enemy->getMoveSpeed());
            enemy->setMoveSpeed(0);
            enemy->setBulletSpeed(0);
        }
    }
    void handleGrenadeEffect() {
        qDebug() << "All enemies removed!";

        QList<QGraphicsItem *> allItems = items();

        for (QGraphicsItem *item : allItems) {
            if (dynamic_cast<Enemy *>(item)) {
                explosion = new Explosion();
                explosion->setPos(item->pos());

                explosionSound->play();
                addItem(explosion);
                explosion->startExplosion();
                removeItem(item);
                delete item;
            }
        }
    }
    void handleShovelEffect();
    void handleTankEffect(){
        health->increase();
    }
    void handleHelmatEffect()
    {
        invincible=true;
        qDebug() << "invincible=true;";
        player->setOpacity(0.5);
        qDebug() << "player->setOpacity(0.5);";
        effectTimer->start(500);
        if (invincible)
            invincibleTimer->start(3000);

    }
    void handleBulletHitPlayer(Player *player)
    {
        qDebug() << "Player hit by bullet!";
        removeItem(player);
        setPlayer(number);
        health->decrease();
    }

    void checkBulletPlayerCollision()
    {
        // 获取场景中的所有子弹和玩家
        QList<QGraphicsItem *> collidingItems = player->collidingItems();

        for (QGraphicsItem *item : collidingItems) {
            // 檢查碰撞的對象是否是子彈
            Bullet *bullet = dynamic_cast<Bullet *>(item);

            if (bullet) {
                // 處理子彈擊中玩家的邏輯
                handleBulletHitPlayer(player);
                removeItem(bullet);  // 移除子彈
                delete bullet;
                break;  // 一旦處理了碰撞，就退出循環
            }
        }
    }
public slots:
    void generateEnemy(int level);
    void increaseScore(Bullet *bullet, Enemy *enemy);
    void hitOnWall(Wall *wall, Bullet *bullet);
    void encounterWall(Wall *wall);


    void togglePlayerOpacity()
    {
        if (player&&invincible) {
            player->setOpacity(player->opacity() == 1.0 ? 0.5 : 1.0);
        }
    }
    void setInvincibe()
    {
        invincible=false;
    }
signals:
    void handleBulletCreation(Bullet *bullet);

private:
    int level;    //等級
    int number;//player人數
    int number_1;
    int remains;
    vector<vector<char>> tanks;
    QGraphicsPixmapItem *survivors;
    QTimer *spawnTimer;
    Player *player;
    Player2 *player2;
    QTimer *timer;
    Score *score;
    Health *health;
    Scene* scene;
    QList<int> keys;
    void slotTimeOut1();
    QTimer* keyRespondTimer1;
    Powerup powerup;
    QSettings settings;
    int bestScore=0;//用來算歷史分數的分數
    vector<vector<char>> matrix;
    bool invincible = false;
    QTimer* invincibleTimer;
    QTimer* effectTimer;
    QTimer* checkTimer;
    bool isTimerPaused=false;
    bool isEnemyMovementFrozen=false;
    QVector<qreal> originalEnemySpeeds;
    QVector<qreal> originalEnemyShoot;
    QList<Enemy*> enemyList;
    int star;//powerup star
    bool BulletFired = false;
    QTimer *shootTimer;
    QTimer *powerupTimer;
    QGraphicsPixmapItem *pauseScreen;
    bool isPaused = false;
    int removedEnemyCount = 0;
    Explosion *explosion;
    QMediaPlayer *explosionSound;
    QMediaPlayer *startSound;
    QMediaPlayer *shootingSound;
    QMediaPlayer *ArmorSound;
    QMediaPlayer *powerupSound;
    QMediaPlayer *powerupGenerateSound;
    QMediaPlayer *moveSound;
    QMediaPlayer *stopSound;
    QAudioOutput* musicOutput;
    QAudioOutput* musicOutput1;
    QAudioOutput* musicOutput2;
    QAudioOutput* musicOutput3;
    QAudioOutput* musicOutput4;
    QAudioOutput* musicOutput5;
    QAudioOutput* musicOutput6;
    QAudioOutput* musicOutput7;
protected:
    void keyPressEvent (QKeyEvent *event)override ;
    void keyReleaseEvent (QKeyEvent *event);
};

#endif // LEVEL_H
