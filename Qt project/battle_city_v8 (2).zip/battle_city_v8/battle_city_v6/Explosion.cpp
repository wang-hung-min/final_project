// Explosion.cpp
#include "Explosion.h"

Explosion::Explosion(QGraphicsItem *parent) : QGraphicsPixmapItem(parent), currentFrame(0), totalFrames(16)
{
    // 設定初始的圖片
    setPixmap(QPixmap(":/images/Effect/explosion"));

    // 設定爆炸動畫的計時器
    explosionTimer = new QTimer(this);
    connect(explosionTimer, &QTimer::timeout, this, &Explosion::updateFrame);
}

void Explosion::startExplosion()
{
    // 啟動爆炸動畫的計時器
    explosionTimer->start(500);  // 調整這個數字以控制動畫速度
}

void Explosion::updateFrame()
{
    // 更新爆炸動畫的當前幀
    currentFrame = (currentFrame + 1) % totalFrames;

    // 計算序列圖片中每一幀的寬度
    int frameWidth = pixmap().width() / totalFrames;

    // 設定顯示的部分
    setPixmap(pixmap().copy(currentFrame * frameWidth, 0, frameWidth, pixmap().height()));

    // 如果動畫結束，停止計時器
    if (currentFrame == totalFrames - 1) {
        explosionTimer->stop();
    }
}
