#ifndef PLAYER2_H
#define PLAYER2_H
#include <QGraphicsPixmapItem>

class Player2: public QGraphicsPixmapItem
{
public:
    Player2();
    int current_player2_Direction=1;
//    void keyPressEvent2(int key);

    QPointF getPrev() const;
    void setPrev(QPointF newPrev);
    QPointF getPos2() const;
    void setPos2(QPointF newPos);

private:
    QPointF prev;
    QPointF pos2;
};

#endif // PLAYER2_H
