#ifndef PLAYER_H
#define PLAYER_H

#include "Bullet.h"
#include "Enemy.h"
#include <QObject>
#include <QGraphicsPixmapItem>

class Player :  public QGraphicsPixmapItem
{
public:
    Player(int who);
    void increaseScore(Bullet *bullet, Enemy *enemy);
    int current_player_Direction=3;

    QPointF getPrev() const;
    void setPrev(QPointF newPrev);
    QPointF getCurPos() const;
    void setCurPos(QPointF newPos);

private:
    QPointF prev;
    QPointF currentPos;
};

#endif // PLAYER_H
