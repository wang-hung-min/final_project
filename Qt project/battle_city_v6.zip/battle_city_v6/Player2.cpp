#include "Player2.h"
#include <QGraphicsRectItem>
#include <QKeyEvent>
#include <QGraphicsPixmapItem>

Player2::Player2()
{
    setPixmap(QPixmap(":/images/Players/Player2.png").scaled(40,40));
}

//void Player2::keyPressEvent2(int key)
//{
//    // qDebug() << "Scene knows you pressed a key2";
//    QPointF pos2 = this->pos();
//    setTransformOriginPoint(boundingRect().center());
//    if (key== Qt::Key_A && pos2.x() > 0) {
//        current_player2_Direction = 1;
//        setRotation(0); // 左邊
//        setPos(pos2 + QPointF(-1, 0));
//    } else if (key== Qt::Key_D && pos2.x() < 700){
//        current_player2_Direction = 2; // 改變方向為右邊
//        setRotation(180); // 右邊
//        setPos(pos2 + QPointF(1, 0));
//    } else if (key == Qt::Key_W) {

//        current_player2_Direction = 3;
//        setRotation(90); // 上面
//        setPos(pos2 + QPointF(0, -1));
//    } else if (key == Qt::Key_S) {

//        current_player2_Direction = 4;
//        setRotation(-90); // 下面
//        setPos(pos2 + QPointF(0, 1));
//    }
//}

QPointF Player2::getPrev() const
{
    return prev;
}

void Player2::setPrev(QPointF newPrev)
{
    prev = newPrev;
}

QPointF Player2::getPos2() const
{
    return pos2;
}
void Player2::setPos2(QPointF newPos)
{
    pos2 = newPos;
}
