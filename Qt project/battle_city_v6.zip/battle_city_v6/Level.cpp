#include "Wall.h"
#include "Flag.h"
#include "Level.h"
#include <QDebug>
#include "Bullet.h"
#include "Enemy.h"
#include <QGraphicsRectItem>
#include <QKeyEvent>
#include <QGraphicsPixmapItem>
#include "Player.h"
#include "Player2.h"
#include "Scene.h"

Level::Level(int level, int number)
    :remains(20),
    tanks({{'f', 'f', 'f', 'f', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'b', 'b', 'b', 'b', 'p', 'p', 'p', 'p'},
           {'p', 'p', 'p', 'p', 'f', 'f', 'f', 'f', 'f', 'f', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'b', 'b'}})
{
    number_1=number;
    generateMap(level);
    setPlayer(number); //決定幾個玩家並生成在初始位置
//    showSurvivor(remains);
    setTankRemainsVector(tanks);

    //定時生成enemy(call generateEnemy)
    spawnTimer = new QTimer(this);
    generateEnemy(level); // 先生成一個初始敵人
    connect(spawnTimer, &QTimer::timeout, this, [this, level](){
        generateEnemy(level);
    });
    spawnTimer->start(8000); // 2000 改成 8000

    // Create the score
    score = new Score();
    addItem(score);

    // Create the health
    health = new Health();
    health->setPos(health->x(), health->y() + 25);
    addItem(health);

    keyRespondTimer1 = new QTimer(this);
    connect(keyRespondTimer1, &QTimer::timeout, this, &Level::slotTimeOut1);

}

void Level::setPlayer(int number)
{
    if(number==1){
        player = new Player(1);
        player->setPos(246,738);
        player->setCurPos(player->pos());
        addItem(player);
    }else{
        player = new Player(1);
        player->setPos(246,738);
        player->setCurPos(player->pos());
        addItem(player);
        player2 = new Player(2);
        player2->setPos(492,738);
        player2->setCurPos(player2->pos());
        addItem(player2);
    }
}

void Level::increaseScore(Bullet *bullet, Enemy *enemy)
{
    removeItem(bullet);
    delete bullet;
    removeItem(enemy);
    delete enemy;
    score->increase();
}

void Level::hitOnWall(Wall *wall, Bullet *bullet)
{
    switch(wall->getTypeIndex()){
        case 0:
            removeItem(bullet);
            delete bullet;
            removeItem(wall);
            delete wall;
            break;
        case 1:
            removeItem(bullet);
            delete bullet;
            break;
        default:
            break;
    }
}

void Level::keyPressEvent(QKeyEvent *event) {
    if (!event->isAutoRepeat()) {
        keys.append(event->key());
    }
    if (!keyRespondTimer1->isActive()) {
        keyRespondTimer1->start(4);
    }
}

void Level::keyReleaseEvent(QKeyEvent *event) {
    if (!event->isAutoRepeat()) {
        keys.removeAll(event->key());
    }
    if (keys.isEmpty()) {
        keyRespondTimer1->stop();
    }
}

void Level::slotTimeOut1() {
    foreach (int key, keys){
        // 這裡處理player1的按鍵事件
        QPointF pos = player->pos();  // Assuming 'player' is the current instance
        player->setTransformOriginPoint(player->boundingRect().center());
        QPointF nextpos = pos;

        if (key == Qt::Key_Left ) {
            player->current_player_Direction = 1;
            player->setRotation(-90); // 左邊
            nextpos = pos + QPointF(-2, 0);
        } else if (key == Qt::Key_Right) {
            player->current_player_Direction = 2; // 改變方向為右邊
            player->setRotation(90); // 右邊
            nextpos = pos + QPointF(2, 0);
        } else if (key == Qt::Key_Up) {
            player->current_player_Direction = 3;
            player->setRotation(0); // 上面
            nextpos = pos + QPointF(0, -2);
        } else if (key == Qt::Key_Down) {
            player->current_player_Direction = 4;
            player->setRotation(180); // 下面
            nextpos = pos + QPointF(0, 2);
        }
        player->setCurPos(nextpos);
        checkPlayerWallCollision(player, player->current_player_Direction);

        player->setPos(player->getCurPos());  // 把player1 在畫面上移到正確的位置


        // player->keyPressEvent1(key);
        if (key == Qt::Key_Space) {
            Bullet *bullet = new Bullet();
            connect(bullet, &Bullet::bulletHitsEnemy, this, &Level::increaseScore);
            //bullet->setPos(player->pos());
            switch (player->current_player_Direction) {
            case 3:
                bullet->setPos(player->x() + player->pixmap().width() / 2 - bullet->pixmap().width() / 2, player->y());
                break;
            case 4:
                bullet->setPos(player->x() + player->pixmap().width() / 2 - bullet->pixmap().width() / 2, player->y() + player->pixmap().height() - bullet->pixmap().height());
                break;
            case 1:
                bullet->setPos(player->x(), player->y() + player->pixmap().height() / 2 - bullet->pixmap().height() / 2);
                break;
            case 2:
                bullet->setPos(player->x() + player->pixmap().width() - bullet->pixmap().width(), player->y() + player->pixmap().height() / 2 - bullet->pixmap().height() / 2);
                break;
            default:
                break;
            }
            bullet->setCurrentDirection(player->current_player_Direction);
            addItem(bullet);
        }
        if(number_1==2){
            // 這裡處理player2的按鍵事件
            QPointF pos2 = player2->pos();  // Assuming 'player' is the current instance
            player2->setTransformOriginPoint(player2->boundingRect().center());
            QPointF nextpos2 = pos2;

            if (key == Qt::Key_A ) {
                player2->current_player_Direction = 1;
                player2->setRotation(-90); // 左邊
                nextpos2 = pos2 + QPointF(-2, 0);
            } else if (key == Qt::Key_D) {
                player2->current_player_Direction = 2; // 改變方向為右邊
                player2->setRotation(90); // 右邊
                nextpos2 = pos2 + QPointF(2, 0);
            } else if (key == Qt::Key_W) {
                player2->current_player_Direction = 3;
                player2->setRotation(0); // 上面
                nextpos2 = pos2 + QPointF(0, -2);
            } else if (key == Qt::Key_S) {
                player2->current_player_Direction = 4;
                player2->setRotation(180); // 下面
                nextpos2 = pos2 + QPointF(0, 2);
            }
            player2->setCurPos(nextpos2);
            checkPlayerWallCollision(player2, player2->current_player_Direction); // 檢查有沒有被牆擋住

            player2->setPos(player2->getCurPos());  // 把player2 在畫面上移到正確的位置


            if (key == Qt::Key_Q) {
                Bullet *bullet = new Bullet();
                connect(bullet, &Bullet::bulletHitsEnemy, this, &Level::increaseScore);
                //bullet->setPos(player->pos());

                switch (player2->current_player_Direction) {
                case 3:
                    bullet->setPos(player2->x() + player2->pixmap().width() / 2 - bullet->pixmap().width() / 2, player2->y());
                    break;
                case 4:
                    bullet->setPos(player2->x() + player2->pixmap().width() / 2 - bullet->pixmap().width() / 2, player2->y() + player2->pixmap().height() - bullet->pixmap().height());
                    break;
                case 1:
                    bullet->setPos(player2->x(), player2->y() + player2->pixmap().height() / 2 - bullet->pixmap().height() / 2);
                    break;
                case 2:
                    bullet->setPos(player2->x() + player2->pixmap().width() - bullet->pixmap().width(), player2->y() + player2->pixmap().height() / 2 - bullet->pixmap().height() / 2);
                    break;
                default:
                    break;
                }
                bullet->setCurrentDirection(player2->current_player_Direction);
                addItem(bullet);
            }
        }
    }
}

void Level::generateMap(int level)
{
    //map 19
    vector<string> data;
    if (level == 1) {
        data = {
            "****bbbb****bbbb****bbbb****bbbb****bbbb****bbbb****",
            "****bbbb****bbbb****bbbb****bbbb****bbbb****bbbb****",
            "****bbbb****bbbb****bbbb****bbbb****bbbb****bbbb****",
            "****bbbb****bbbb****bbbb****bbbb****bbbb****bbbb****",
            "****bbbb****bbbb****bbbb****bbbb****bbbb****bbbb****",
            "****bbbb****bbbb****bbbb****bbbb****bbbb****bbbb****",
            "****bbbb****bbbb****bbbb****bbbb****bbbb****bbbb****",
            "****bbbb****bbbb****bbbb****bbbb****bbbb****bbbb****",
            "****bbbb****bbbb****bbbb****bbbb****bbbb****bbbb****",
            "****ssss****ssss****ssss****ssss****ssss****ssss****",
            "****ssss****ssss****ssss****ssss****ssss****ssss****",
            "****************************************************",
            "****************************************************",
            "****************bbbb************bbbb****************",
            "****************bbbb************bbbb****************",
            "bbbb****bbbb****bbbb************bbbb****bbbb****bbbb",
            "bbbb****bbbb****bbbb************bbbb****bbbb****bbbb",
            "bbbb****bbbbbbbbbbbb****bbbb****bbbbbbbbbbbb****bbbb",
            "bbbb****bbbbbbbbbbbb****bbbb****bbbbbbbbbbbb****bbbb",
            "bbbb****bbbb****bbbb****bbbb****bbbb****bbbb****bbbb",
            "bbbb****bbbb****bbbb****bbbb****bbbb****bbbb****bbbb",
            "ssss****ssss****ssss****ssss****ssss****ssss****ssss",
            "ssss****ssss****ssss****ssss****ssss****ssss****ssss",
            "****************ssss************ssss****************",
            "****************ssss************ssss****************",
            "tttttttt********bbbb****tttt****bbbb********tttttttt",
            "tttttttt********bbbb****tttt****bbbb********tttttttt",
            "tttttttt********bbbb****tttt****bbbb********tttttttt",
            "tttttttt********bbbb****tttt****bbbb********tttttttt",
            "ttttttttttttttttbbbbbbbbttttbbbbbbbbtttttttttttttttt",
            "ttttttttttttttttbbbbbbbbttttbbbbbbbbtttttttttttttttt",
            "ttttttttttttttttbbbb****tttt****bbbbtttttttttttttttt",
            "ttttttttttttttttbbbb****tttt****bbbbtttttttttttttttt",
            "tttttttttttttttttttttttttttttttttttttttttttttttttttt",
            "tttttttttttttttttttttttttttttttttttttttttttttttttttt",
            "tttttttttttttttttttttttttttttttttttttttttttttttttttt",
            "tttttttttttttttttttttttttttttttttttttttttttttttttttt",
            "****************bbbbttttttttttttbbbb****************",
            "****************bbbbttttttttttttbbbb****************",
            "bbbb****bbbb****bbbbttttttttttttbbbb****bbbb****bbbb",
            "bbbb****bbbb****bbbbttttttttttttbbbb****bbbb****bbbb",
            "****bbbb****bbbb********tttt********bbbb****bbbb****",
            "****bbbb****bbbb********tttt********bbbb****bbbb****",
            "****bbbb****bbbb********tttt********bbbb****bbbb****",
            "****bbbb****bbbb********************bbbb****bbbb****",
            "****bbbb****bbbb********************bbbb****bbbb****",
            "****bbbb****bbbb****bbbbbbbbbbbb****bbbb****bbbb****",
            "****bbbb****bbbb****bbbbbbbbbbbb****bbbb****bbbb****",
            "****bbbb****bbbb****bbbbf***bbbb****bbbb****bbbb****",
            "****bbbb****bbbb****bbbb****bbbb****bbbb****bbbb****",
            "********************bbbb****bbbb********************",
            "********************bbbb****bbbb********************"
        };
    } else {
        //map 28
        data = {
                "****************************************************",
                "****************************************************",
                "****************************************************",
                "****************************************************",
                "****************bbbb****bbbb************************",
                "****************bbbb****bbbb************************",
                "****************bbbb****bbbb************************",
                "****************bbbb****bbbb************************",
                "tttt********ttttbbbbttttbbbbtttt********tttt********",
                "tttt********ttttbbbbttttbbbbtttt********tttt********",
                "tttt********ttttbbbbttttbbbbtttt********tttt********",
                "tttt********ttttbbbbttttbbbbtttt********tttt********",
                "bbbbttttttttbbbbbbbbbbbbbbbbbbbbttttttttbbbbtttt****",
                "bbbbttttttttbbbbbbbbbbbbbbbbbbbbttttttttbbbbtttt****",
                "bbbbttttttttbbbbbbbbbbbbbbbbbbbbttttttttbbbbtttt****",
                "bbbbttttttttbbbbbbbbbbbbbbbbbbbbttttttttbbbbtttt****",
                "bbbbbbbbbbbbbbbbssssbbbbssssbbbbbbbbbbbbbbbbtttt****",
                "bbbbbbbbbbbbbbbbssssbbbbssssbbbbbbbbbbbbbbbbtttt****",
                "bbbbbbbbbbbbbbbbssssbbbbssssbbbbbbbbbbbbbbbbtttt****",
                "bbbbbbbbbbbbbbbbssssbbbbssssbbbbbbbbbbbbbbbbtttt****",
                "wwwwwwwwwwwwbbbbbbbbbbbbbbbbbbbbwwwwwwwwwwwwtttt****",
                "wwwwwwwwwwwwbbbbbbbbbbbbbbbbbbbbwwwwwwwwwwwwtttt****",
                "wwwwwwwwwwwwbbbbbbbbbbbbbbbbbbbbwwwwwwwwwwwwtttt****",
                "wwwwwwwwwwwwbbbbbbbbbbbbbbbbbbbbwwwwwwwwwwwwtttt****",
                "wwwwbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbwwwwwwwwtttt",
                "wwwwbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbwwwwwwwwtttt",
                "wwwwbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbwwwwwwwwtttt",
                "wwwwbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbwwwwwwwwtttt",
                "bbbbbbbbbbbbwwwwbbbbbbbbbbbbwwwwbbbbbbbbbbbbtttttttt",
                "bbbbbbbbbbbbwwwwbbbbbbbbbbbbwwwwbbbbbbbbbbbbtttttttt",
                "bbbbbbbbbbbbwwwwbbbbbbbbbbbbwwwwbbbbbbbbbbbbtttttttt",
                "bbbbbbbbbbbbwwwwbbbbbbbbbbbbwwwwbbbbbbbbbbbbtttttttt",
                "bbbbbbbbwwwwwwwwwwwwbbbbwwwwwwwwwwwwbbbbbbbbwwwwwwww",
                "bbbbbbbbwwwwwwwwwwwwbbbbwwwwwwwwwwwwbbbbbbbbwwwwwwww",
                "bbbbbbbbwwwwwwwwwwwwbbbbwwwwwwwwwwwwbbbbbbbbwwwwwwww",
                "bbbbbbbbwwwwwwwwwwwwbbbbwwwwwwwwwwwwbbbbbbbbwwwwwwww",
                "ttttwwwwwwwwttttttttttttttttttttwwwwwwwwttttwwwwtttt",
                "ttttwwwwwwwwttttttttttttttttttttwwwwwwwwttttwwwwtttt",
                "ttttwwwwwwwwttttttttttttttttttttwwwwwwwwttttwwwwtttt",
                "ttttwwwwwwwwttttttttttttttttttttwwwwwwwwttttwwwwtttt",
                "****tttttttt********************tttttttt****tttt****",
                "****tttttttt********************tttttttt****tttt****",
                "****tttttttt********************tttttttt****tttt****",
                "****tttttttt********************tttttttt****tttt****",
                "****************************************************",
                "****************************************************",
                "********************bbbbbbbbbbbb********************",
                "********************bbbbbbbbbbbb********************",
                "********************bbbbf***bbbb********************",
                "********************bbbb****bbbb********************",
                "********************bbbb****bbbb********************",
                "********************bbbb****bbbb********************"
        };
    }

    float i = 0;
    float j = 0;

    //setPos
    for (const auto& rowVector : data) {
        i = 0; //寫完一row就回到0
        for (char element : rowVector) {
            if (element != '*'){
                if (element == 'f'){
                    Flag *flag = new Flag();
                    addItem(flag);
                    flag->setPos(370, 740);
                }
                else{
                    Wall *wall = new Wall(element);
                    addItem(wall);
                    wall->setPos(i ,j);
                    connect(wall, &Wall::breakWall, this, &Level::hitOnWall);
                }
            }
            i += 800/52; //這裡還要再根據圖片大小做調整
        }
        j += 800/52;       //這裡還要再根據圖片大小做調整
    }
}

void Level::setTankRemainsVector(const vector<vector<char> > &tankRemains)
{
    tanks = tankRemains;
}

const vector<vector<char> > &Level::getTankRemainsVector() const
{
    return tanks;
}

void Level::generateEnemy(int level)
{
    //用connect,當timeout就生成一隻tank
    getTankRemainsVector();
    Enemy *enemy = new Enemy();
    addItem(enemy);
    //並將其從vector裡刪除
    if(!tanks[level-1].empty())
    {
        qDebug()<<"delete picture...";
        tanks[level-1].erase(tanks[level-1].begin());
        setTankRemainsVector(tanks);
    }
    else
    {
        qDebug()<<"finish deleting";
        spawnTimer->stop();
    }
}

void Level::checkPlayerWallCollision(Player *player, int playerDir) {
    QPointF pos = player->pos();
    QPointF nextpos = player->getCurPos();  // 玩家下一步的位置

    // 遍歷所有牆，看是否與玩家發生碰撞
    for (QGraphicsItem *item : items()) {
        Wall *wall = dynamic_cast<Wall*>(item);
        if (wall) {
            switch(wall->getTypeIndex()){
            case 0:
            case 1:
            case 3:
                // 如果以下情況，阻止玩家移動
                // 1. 若往左走小於牆的x
                // 2. 若往右走大於牆的x
                // 3. 若往上走小於牆的y
                // 4. 若往下走大於牆的y
                if (nextpos.x() < wall->pos().x() + wall->boundingRect().width() &&
                    nextpos.x() + player->pixmap().width() > wall->pos().x() &&
                    nextpos.y() < wall->pos().y() + wall->boundingRect().height() &&
                    nextpos.y() + player->pixmap().height() > wall->pos().y()) {
                    player->setCurPos(pos);  // 玩家位置還原當前位置
                    return;
                }
            }
        }
    }
}
