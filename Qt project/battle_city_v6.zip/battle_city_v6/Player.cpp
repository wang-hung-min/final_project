#include "Player.h"
#include <QGraphicsRectItem>
#include <QKeyEvent>
#include <QGraphicsPixmapItem>

Player::Player(int who)
{
    if (who == 1)
        setPixmap(QPixmap(":/images/Players/Player1.png").scaled(40,40));
    else if (who == 2)
        setPixmap(QPixmap(":/images/Players/Player2.png").scaled(40,40));
}

QPointF Player::getPrev() const
{
    return prev;
}

void Player::setPrev(QPointF newPrev)
{
    prev = newPrev;
}

QPointF Player::getCurPos() const
{
    return currentPos;
}

void Player::setCurPos(QPointF newPos)
{
    currentPos = newPos;
}

