#include "Wall.h"
#include "Flag.h"
#include "Level.h"
#include <QDebug>
#include "Bullet.h"
#include "Enemy.h"
#include <QGraphicsRectItem>
#include <QKeyEvent>
#include <QGraphicsPixmapItem>
#include "Player.h"
#include "Player2.h"
#include "Scene.h"

Level::Level(int level, int number)
    :remains(20),
    tanks({{'f', 'f', 'f', 'f', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'b', 'b', 'b', 'b', 'p', 'p', 'p', 'p'},
           {'p', 'p', 'p', 'p', 'f', 'f', 'f', 'f', 'f', 'f', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'b', 'b'}})

{
    number_1=number;
    generateMap(level);
    setPlayer(number); //決定幾個玩家並生成在初始位置
    showSurvivor(remains);
    setTankRemainsVector(tanks);

    //定時生成enemy(call generateEnemy)
    spawnTimer = new QTimer(this);
    generateEnemy(level); // 先生成一個初始敵人
    connect(spawnTimer, &QTimer::timeout, this, [this, level](){
        generateEnemy(level);
    });
    spawnTimer->start(8000); // 2000 改成 8000

    // Create the score
    score = new Score();
    addItem(score);

    // Create the health
    health = new Health();
    health->setPos(health->x(), health->y() + 25);
    addItem(health);

    keyRespondTimer1 = new QTimer(this);
    connect(keyRespondTimer1, &QTimer::timeout, this, &Level::slotTimeOut1);

}

void Level::setPlayer(int number)
{
    if(number==1){
        player = new Player();
        player->setPos(200, 550);
        addItem(player);
    }else{
        player = new Player();
        player->setPos(200, 550);
        addItem(player);
        player2 = new Player2();
        player2->setPos(600, 550); // 根據您的需求設定初始位置
        addItem(player2);
    }
}

void Level::increaseScore(Bullet *bullet, Enemy *enemy)
{
    removeItem(bullet);
    delete bullet;
    removeItem(enemy);
    delete enemy;
    score->increase();
}

void Level::hitOnWall(Wall *wall, Bullet *bullet)
{
    //qDebug() << wall->getTypeIndex();
    switch(wall->getTypeIndex()){
        case 0:
            removeItem(bullet);
            delete bullet;
            removeItem(wall);
            delete wall;
            break;
        case 1:
            removeItem(bullet);
            delete bullet;
            break;
        default:
            break;
    }
}

void Level::encounterWall(Wall *wall)
{

    //player->setPos1(player->pos()); // pos1 紀錄移動前

    switch(wall->getTypeIndex()){
        case 0:
        case 1:
        case 3:
            qDebug() << "Hi"; // 有觸發
            player->setColliding(true);
            player->setPos(player->getPrev()); // 把圖片退回前一步
//            player->setColliding(false);
            break;
        default:
            break;
    }
}


void Level::keyPressEvent(QKeyEvent *event) {
    if (!event->isAutoRepeat()) {
            keys.append(event->key());
    }
    if (!keyRespondTimer1->isActive()) {
            keyRespondTimer1->start(4);
    }
}

void Level::keyReleaseEvent(QKeyEvent *event) {
    if (!event->isAutoRepeat()) {
            keys.removeAll(event->key());
    }
    if (keys.isEmpty()) {
            keyRespondTimer1->stop();
    }
}



void Level::slotTimeOut1() {

    //player->keyPressEvent1(keys); // 這裡處理player1的按鍵事件
    foreach (int key, keys){
        player->keyPressEvent1(key);
        if (key == Qt::Key_Space) {
            Bullet *bullet = new Bullet();
            connect(bullet, &Bullet::bulletHitsEnemy, this, &Level::increaseScore);
            //bullet->setPos(player->pos());
            switch (player->current_player_Direction) {
            case 3:
                bullet->setPos(player->x() + player->pixmap().width() / 2 - bullet->pixmap().width() / 2, player->y());
                break;
            case 4:
                bullet->setPos(player->x() + player->pixmap().width() / 2 - bullet->pixmap().width() / 2, player->y() + player->pixmap().height() - bullet->pixmap().height());
                break;
            case 1:
                bullet->setPos(player->x(), player->y() + player->pixmap().height() / 2 - bullet->pixmap().height() / 2);
                break;
            case 2:
                bullet->setPos(player->x() + player->pixmap().width() - bullet->pixmap().width(), player->y() + player->pixmap().height() / 2 - bullet->pixmap().height() / 2);
                break;
            default:
                break;
            }
            bullet->setCurrentDirection(player->current_player_Direction);
            addItem(bullet);
        }
        if(number_1==2){
            player2->keyPressEvent2(key); // 這裡處理player2的按鍵事件

            if (key == Qt::Key_Q) {
                Bullet *bullet = new Bullet();
                connect(bullet, &Bullet::bulletHitsEnemy, this, &Level::increaseScore);
                //bullet->setPos(player->pos());

                switch (player2->current_player2_Direction) {
                case 3:
                    bullet->setPos(player2->x() + player2->pixmap().width() / 2 - bullet->pixmap().width() / 2, player2->y());
                    break;
                case 4:
                    bullet->setPos(player2->x() + player2->pixmap().width() / 2 - bullet->pixmap().width() / 2, player2->y() + player2->pixmap().height() - bullet->pixmap().height());
                    break;
                case 1:
                    bullet->setPos(player2->x(), player2->y() + player2->pixmap().height() / 2 - bullet->pixmap().height() / 2);
                    break;
                case 2:
                    bullet->setPos(player2->x() + player2->pixmap().width() - bullet->pixmap().width(), player2->y() + player2->pixmap().height() / 2 - bullet->pixmap().height() / 2);
                    break;
                default:
                    break;
                }
                bullet->setCurrentDirection(player2->current_player2_Direction);
                addItem(bullet);
            }
        }}
}

void Level::generateMap(int level)
{
    //map 19
    vector<string> data;
    if (level == 1) {
        data = {
            "****####****####****####****####****####****####****",//layer1
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****####****####****####****####****####****####****",
            "****&&&&****&&&&****&&&&****&&&&****&&&&****&&&&****",
            "****&&&&****&&&&****&&&&****&&&&****&&&&****&&&&****",
            "****************************************************",
            "****************************************************",
            "****************####************####****************",//layer2
            "****************####************####****************",
            "####****####****####************####****####****####",
            "####****####****####************####****####****####",
            "####****############****####****############****####",
            "####****############****####****############****####",
            "####****####****####****####****####****####****####",
            "####****####****####****####****####****####****####",
            "&&&&****&&&&****&&&&****&&&&****&&&&****&&&&****&&&&",
            "&&&&****&&&&****&&&&****&&&&****&&&&****&&&&****&&&&",
            "****************&&&&************&&&&****************",
            "****************&&&&************&&&&****************",
            "%%%%%%%%********####****%%%%****####********%%%%%%%%",//layer3
            "%%%%%%%%********####****%%%%****####********%%%%%%%%",
            "%%%%%%%%********####****%%%%****####********%%%%%%%%",
            "%%%%%%%%********####****%%%%****####********%%%%%%%%",
            "%%%%%%%%%%%%%%%%########%%%%########%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%########%%%%########%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%####****%%%%****####%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%####****%%%%****####%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%",
            "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%",
            "****************####%%%%%%%%%%%%####****************",
            "****************####%%%%%%%%%%%%####****************",
            "####****####****####%%%%%%%%%%%%####****####****####",
            "####****####****####%%%%%%%%%%%%####****####****####",
            "****####****####********%%%%********####****####****",//layer4
            "****####****####********%%%%********####****####****",
            "****####****####********%%%%********####****####****",
            "****####****####********************####****####****",
            "****####****####********************####****####****",
            "****####****####****############****####****####****",
            "****####****####****############****####****####****",
            "****####****####****####f***####****####****####****",
            "****####****####****####****####****####****####****",
            "********************####****####********************",
            "********************####****####********************"
        };
    } else {
        //map 28
        data = {
            "****************************************************",
            "****************************************************",
            "****************************************************",
            "****************************************************",
            "****************####****####************************",
            "****************####****####************************",
            "****************####****####************************",
            "****************####****####************************",
            "%%%%********%%%%####%%%%####%%%%********%%%%********",
            "%%%%********%%%%####%%%%####%%%%********%%%%********",
            "%%%%********%%%%####%%%%####%%%%********%%%%********",
            "%%%%********%%%%####%%%%####%%%%********%%%%********",
            "####%%%%%%%%####################%%%%%%%%####%%%%****",
            "####%%%%%%%%####################%%%%%%%%####%%%%****",
            "####%%%%%%%%####################%%%%%%%%####%%%%****",
            "####%%%%%%%%####################%%%%%%%%####%%%%****",
            "################&&&&####&&&&################%%%%****",
            "################&&&&####&&&&################%%%%****",
            "################&&&&####&&&&################%%%%****",
            "################&&&&####&&&&################%%%%****",
            "@@@@@@@@@@@@####################@@@@@@@@@@@@%%%%****",
            "@@@@@@@@@@@@####################@@@@@@@@@@@@%%%%****",
            "@@@@@@@@@@@@####################@@@@@@@@@@@@%%%%****",
            "@@@@@@@@@@@@####################@@@@@@@@@@@@%%%%****",
            "@@@@####################################@@@@@@@@%%%%",
            "@@@@####################################@@@@@@@@%%%%",
            "@@@@####################################@@@@@@@@%%%%",
            "@@@@####################################@@@@@@@@%%%%",
            "############@@@@############@@@@############%%%%%%%%",
            "############@@@@############@@@@############%%%%%%%%",
            "############@@@@############@@@@############%%%%%%%%",
            "############@@@@############@@@@############%%%%%%%%",
            "########@@@@@@@@@@@@####@@@@@@@@@@@@########@@@@@@@@",
            "########@@@@@@@@@@@@####@@@@@@@@@@@@########@@@@@@@@",
            "########@@@@@@@@@@@@####@@@@@@@@@@@@########@@@@@@@@",
            "########@@@@@@@@@@@@####@@@@@@@@@@@@########@@@@@@@@",
            "%%%%@@@@@@@@%%%%%%%%%%%%%%%%%%%%@@@@@@@@%%%%@@@@%%%%",
            "%%%%@@@@@@@@%%%%%%%%%%%%%%%%%%%%@@@@@@@@%%%%@@@@%%%%",
            "%%%%@@@@@@@@%%%%%%%%%%%%%%%%%%%%@@@@@@@@%%%%@@@@%%%%",
            "%%%%@@@@@@@@%%%%%%%%%%%%%%%%%%%%@@@@@@@@%%%%@@@@%%%%",
            "****%%%%%%%%********************%%%%%%%%****%%%%****",
            "****%%%%%%%%********************%%%%%%%%****%%%%****",
            "****%%%%%%%%********************%%%%%%%%****%%%%****",
            "****%%%%%%%%********************%%%%%%%%****%%%%****",
            "****************************************************",
            "****************************************************",
            "********************############********************",
            "********************############********************",
            "********************####f***####********************",
            "********************####****####********************",
            "********************####****####********************",
            "********************####****####********************"
        };
    }

    //存成二維陣列
    vector<vector<char>> matrix;
    for (const string& row : data) {
        vector<char> rowVector(row.begin(), row.end());
        matrix.push_back(rowVector);
    }

    float i = 0;
    float j = 0;

    //setPos
    for (const auto& rowVector : matrix) {
        i = 0; //寫完一row就回到0
        for (char element : rowVector) {
            if (element == '#') {
                Wall *wall = new Wall('b');
                addItem(wall);
                wall->setPos(i ,j);
                connect(wall, &Wall::breakWall, this, &Level::hitOnWall);
                connect(wall, &Wall::wallBlockTank, [=](){
                    encounterWall(wall);
                    player->setPos(player->getPrev()); // 把圖片退回前一步
                });
            } else if (element == '&') {
                Wall *wall = new Wall('s');
                addItem(wall);
                wall->setPos(i, j);
                connect(wall, &Wall::breakWall, this, &Level::hitOnWall);
                connect(wall, &Wall::wallBlockTank, this, &Level::encounterWall);
            } else if (element == '%') {
                Wall *wall = new Wall('t');
                addItem(wall);
                wall->setPos(i, j);
            } else if (element == '@') {
                Wall *wall = new Wall('w');
                addItem(wall);
                wall->setPos(i, j);
                connect(wall, &Wall::wallBlockTank, this, &Level::encounterWall);
            } else if (element == '$') {
                Wall *wall = new Wall('i');
                addItem(wall);
                wall->setPos(i, j);
            } else if (element == 'f') {
                Flag *flag = new Flag();
                addItem(flag);
                flag->setPos(370, 740);
            } else {
                i+=800/52; //這裡還要再根據圖片大小做調整
                continue;  //空白，不用放東西
            }
            i += 800/52; //這裡還要再根據圖片大小做調整
        }
        j += 800/52;       //這裡還要再根據圖片大小做調整
    }
}

void Level::setTankRemainsVector(const vector<vector<char> > &tankRemains)
{
    tanks = tankRemains;
}

const vector<vector<char> > &Level::getTankRemainsVector() const
{
    return tanks;
}

void Level::generateEnemy(int level)
{
    //用connect,當timeout就生成一隻tank
    getTankRemainsVector();
    Enemy *enemy = new Enemy();
    addItem(enemy);
    //並將其從vector裡刪除
    if(!tanks[level-1].empty())
    {
        qDebug()<<"delete picture...";
        tanks[level-1].erase(tanks[level-1].begin());
        setTankRemainsVector(tanks);
    }
    else
    {
        qDebug()<<"finish deleting";
        spawnTimer->stop();
    }
    showSurvivor(--remains);
}

//還要寫個刪除所有圖片的
void Level::showSurvivor(int remains)
{
    int x=740;
    int y=60;
    //生成初始ramaining survivors，共20台，10*2
    for (int i=1; i<=remains/2; i++){
        for (int j=1; j<=2; j++){
            survivors = new QGraphicsPixmapItem(QPixmap(":/images/Enemies/Remains.png"));
            survivors->setPos(x, y);
            addItem(survivors);
            x+=10;
            y+=40;
        }
        x-=20;
    }
    //處理最後一排(mod為奇數時進入)
    for (int k = 1; k <= remains % 2; k++) {
        y+=40;
        survivors = new QGraphicsPixmapItem(QPixmap(":/images/Enemies/Remains.png"));
        survivors->setPos(x, y);
        addItem(survivors);
    }
}
