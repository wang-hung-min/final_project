#include "Level.h"

Level::Level(QObject *parent) : QGraphicsScene {parent}
{
    flag = new Flag();
    wall = new Wall('b');
    addItem(flag);
    addItem(wall);
}
