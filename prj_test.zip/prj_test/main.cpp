#include "widget.h"
#include "Flag.h"
#include "Wall.h"

#include <QApplication>
#include <QGraphicsView>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    w.show();

//    QGraphicsScene scene;
//    scene.setSceneRect(0,0,800,600);

//    Flag flag;
//    Wall *brick = new Wall('b');
//    Wall *steel = new Wall('s');

//    QGraphicsView view(&scene);
//    scene.addItem(&flag);
//    scene.addItem(brick);
//    scene.addItem(steel);

//    view.show();


    return a.exec();
}
