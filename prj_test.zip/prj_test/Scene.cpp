#include "Scene.h"

#include <QObject>
#include <QGraphicsScene>
#include <QGraphicsSceneMouseEvent>
#include <QDebug>

Scene::Scene(QObject *parent) : QGraphicsScene {parent}
{
    flag = new Flag();
    wall = new Wall('w');
    addItem(flag);
    addItem(wall);
}

void Scene::mousePressEvent(QGraphicsSceneMouseEvent *event){
    if (event->button() == Qt::LeftButton){
        emit changeScene();
        qDebug() << "Press...";
    }
}
