#include "widget.h"
#include "ui_widget.h"

#include <QObject>
#include <QKeyEvent>
#include <QGraphicsSceneMouseEvent>
#include <QDebug>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget), scene(new Scene), level(new Level)
{
    QGraphicsPixmapItem *pixItem = new QGraphicsPixmapItem(QPixmap(":/image/Trees.png").scaled(800,600));

    ui->setupUi(this);
    // 設定遊戲場景為 800 * 600
    // (x0, y0, width, height)
    scene->setSceneRect(0, 0, 800, 600);
    scene->addItem(pixItem);

    // 設定展示畫面
    ui->graphicsView->setScene(scene);
    ui->graphicsView->setFixedSize(800, 600);
    // 關閉水平、垂直滾動條
    ui->graphicsView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->graphicsView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    // 用 QBrush 的方式畫上找好的場景圖片
    //ui->graphicsView->setBackgroundBrush(QBrush(QImage(":/image/Trees.png")));

    connect(scene, &Scene::changeScene, [=](){
        ui->graphicsView->setScene(level);
        ui->graphicsView->setBackgroundBrush(QBrush(QImage(":/image/Ice.png")));
    });
}

void Widget::keyPressEvent(QKeyEvent *event){
    if (event->key() == Qt::Key_Left)
    {
        QGraphicsPixmapItem *pixItem = new QGraphicsPixmapItem(QPixmap(":/image/Ice.png"));
        ui->graphicsView->setScene(level);
        level->addItem(pixItem);
        qDebug() << "Press change...";
    }
}

Widget::~Widget()
{
    delete ui;
}

