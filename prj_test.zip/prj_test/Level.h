#ifndef LEVEL_H
#define LEVEL_H

#include "Flag.h"
#include "Wall.h"

#include <QGraphicsScene>
#include <QObject>


class Level : public QGraphicsScene
{
    // 元物件（使用 signals and slots 時需引用）
    Q_OBJECT
public:
    explicit Level(QObject *parent = nullptr);

private:
    Flag *flag;
    Wall *wall;

    // QGraphicsScene interface
    // virtual function: 可以根據 datatype，決定要呼叫的是 QGraphicsScene的，還是我們複寫的 Scene 版本 keyPressEven


    // QGraphicsScene interface
};

#endif // LEVEL_H
